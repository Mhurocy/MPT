To Install: Extract Bepinex and user folder into your SPT folder.

If upgrading from pre SAIN 2.2 version: Remove SAIN.dll from Bepinex/Plugins folder. New dll is in the SAIN folder.

Make sure you have BigBrain and Waypoints, or SAIN will fail to load!