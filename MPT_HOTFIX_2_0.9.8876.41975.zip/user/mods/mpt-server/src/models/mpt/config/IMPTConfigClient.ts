export interface IMPTConfigClient {
    useBtr: boolean;
    friendlyFire: boolean;
    dynamicVExfils: boolean;
    allowFreeCam: boolean;
}
