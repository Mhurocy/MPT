export interface IMPTRaidGethostResponse {
    ip: string;
    port: number;
}
