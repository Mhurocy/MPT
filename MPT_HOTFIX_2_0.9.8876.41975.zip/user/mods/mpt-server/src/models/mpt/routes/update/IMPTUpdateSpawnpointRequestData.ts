export interface IMPTUpdateSpawnpointRequestData {
    serverId: string;
    name: string;
}
