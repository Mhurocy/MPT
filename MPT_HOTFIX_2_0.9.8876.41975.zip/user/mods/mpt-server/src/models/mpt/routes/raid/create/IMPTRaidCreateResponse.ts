export interface IMPTRaidCreateResponse {
    success: boolean;
}
