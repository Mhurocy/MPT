export interface IMPTSendItemRequestData {
    id: string;
    target: string;
}
