export interface IMPTRaidJoinRequestData {
    serverId: string;
    profileId: string;
}
