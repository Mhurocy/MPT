export interface IMPTUpdatePingRequestData {
    serverId: string;
}
