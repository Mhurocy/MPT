export interface IMPTSenditemAvailablereceiversRequestData {
    id: string;
}
