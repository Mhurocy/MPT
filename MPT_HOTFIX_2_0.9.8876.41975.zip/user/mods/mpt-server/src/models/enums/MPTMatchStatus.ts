export enum MPTMatchStatus {
    LOADING = 0,
    IN_GAME = 1,
    COMPLETE = 2
}
