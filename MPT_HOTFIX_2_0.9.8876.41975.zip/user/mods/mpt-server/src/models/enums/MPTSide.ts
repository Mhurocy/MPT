export enum MPTSide {
    PMC = 0,
    Savage = 1
}