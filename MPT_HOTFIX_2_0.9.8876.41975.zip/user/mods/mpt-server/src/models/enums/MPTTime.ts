export enum MPTTime {
    CURR = 0,
    PAST = 1
}